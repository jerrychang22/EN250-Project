#ifndef _OUTPUT_HPP_
#define _OUTPUT_HPP_

struct PIXEL { /* color table  */
  unsigned char B;
  unsigned char G;
  unsigned char R;
};




#endif
